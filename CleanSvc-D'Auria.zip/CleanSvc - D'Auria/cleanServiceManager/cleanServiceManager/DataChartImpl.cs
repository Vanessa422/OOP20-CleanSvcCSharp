﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cleanServiceManager
{
    public class DataChartImpl : IDataChart
    {
        private static int gainIndex = 1;
        private static int workTimeIndex = 2;
        private static double maxGain = 50000.00;
        private static double maxTime = 23.59;
        Random rand = new Random();

        public Dictionary<DateTime, Double> ChoiceFromInput(DateTime dateStart, DateTime dateEnd, int choice)
        {
            if (dateStart <= dateEnd && (choice.Equals(gainIndex) || choice.Equals(workTimeIndex)))
            {
                if (choice.Equals(gainIndex))
                {
                    return this.GetGain(dateStart, dateEnd);
                }
                else
                {
                    return this.GetWorkTime(dateStart, dateEnd);
                }
            }
            else
                Console.WriteLine("Non è possibile visualizzare dati per la scelta selezionata, correggere data o scelta.");
                return null;
        }

        public Dictionary<DateTime, Double> GetGain(DateTime dateStart, DateTime dateEnd)
        {
            Dictionary<DateTime, Double> auxMap = new Dictionary<DateTime, double>();
            DateTime auxDate = dateStart;
            double gainPerDay;
            Console.WriteLine("Calculating...");
           
            while (auxDate <= dateEnd)
            {
                gainPerDay = rand.NextDouble() * maxGain + maxGain;
                auxMap.Add(auxDate, gainPerDay);
                auxDate = auxDate.AddDays(1);
                Console.WriteLine(auxDate.ToShortDateString() + " " + gainPerDay.ToString("#.##"));
            }
            
            return auxMap; 
        }

        public Dictionary<DateTime, Double> GetWorkTime(DateTime dateStart, DateTime dateEnd)
        {
            Dictionary<DateTime, Double> auxMap = new Dictionary<DateTime, double>();
            DateTime auxDate = dateStart;
             double workTime;
            Console.WriteLine("Calculating...");

            while (auxDate <= dateEnd)
            {
                workTime = rand.NextDouble() * maxTime + maxTime;
                auxMap.Add(auxDate, workTime);
                auxDate = auxDate.AddDays(1);
                Console.WriteLine(auxDate.ToShortDateString() + " " + workTime.ToString("#.##") );
            }
           
            return auxMap;
        }
    }
}
