﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cleanServiceManager
{
    class Program
    {
        static void Main(string[] args)
        {

            DataChartImpl dC = new DataChartImpl();
            String confirm;
            do
            {
                Console.WriteLine("Inserisci data di partenza (yyyy/mm/dd):");
                DateTime dateStart = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Inserisci data di arrivo (yyyy/mm/dd):");
                DateTime dateEnd = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Inserisci dato da visualizzare \n" + "{1} Profitti \n" + "{2} Tempo di lavoro \n");
                int choice = int.Parse(Console.ReadLine());
                dC.ChoiceFromInput(dateStart, dateEnd, choice);
                Console.Write("Visualizzare altri dati? \n" + "Y o y per continuare, qualsiasi altro tasto per uscire: ");
                confirm = Console.ReadLine();
            } while (confirm == "y" || confirm == "Y");

        }
    }
}
