﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cleanServiceManager
{
    interface IDataChart
    {
        Dictionary<DateTime,Double> ChoiceFromInput(DateTime dateStart, DateTime dateEnd, int choice);

        Dictionary<DateTime,Double> GetGain(DateTime dateStart, DateTime dateEnd);

        Dictionary<DateTime,Double> GetWorkTime(DateTime dateStart, DateTime dateEnd);

    }
}
