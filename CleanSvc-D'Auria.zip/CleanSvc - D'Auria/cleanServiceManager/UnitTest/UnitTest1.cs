﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using cleanServiceManager;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {

        private static DateTime dateStart = new DateTime(2021, 02, 03);
        private static DateTime dateEnd = new DateTime(2021, 02, 09);
        private static int gainIndex = 1;
        private static int workTimeIndex = 2;
        private static int wrongChoice = 3;

        [TestMethod]
        public void TestGain()
        {
            Assert.IsNotNull(new DataChartImpl().ChoiceFromInput(dateStart, dateEnd, gainIndex));
        }

        [TestMethod]
        public void TestWorkTime()
        {
            Assert.IsNotNull(new DataChartImpl().ChoiceFromInput(dateStart, dateEnd, workTimeIndex));
        }

        [TestMethod]
        public void WrongDateOrder()
        {
            Assert.IsNull(new DataChartImpl().ChoiceFromInput(dateEnd, dateStart, gainIndex));
        }

        [TestMethod]
        public void WrongChoice()
        {
            Assert.IsNull(new DataChartImpl().ChoiceFromInput(dateEnd, dateStart, wrongChoice));
        }

    }
}
