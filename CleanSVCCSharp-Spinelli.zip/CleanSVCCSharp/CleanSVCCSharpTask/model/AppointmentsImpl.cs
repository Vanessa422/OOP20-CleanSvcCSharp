public class AppointmentsImpl : IAppointments 
{
    public string Date { get; }
    public string Hour { get; }
    public IClients Client { get; }
    public double Time { get; }
    public double Earn { get; }

    public AppointmentsImpl(string date, string hour, IClients client, double time, double earn) 
    {
        this.Date = date;
        this.Hour = hour;
        this.Client = client;
        this.Time = time;
        this.Earn = earn;
    }
}
