public interface IAppointments 
{
    string Date { get; }
    string Hour { get; }
    IClients Client { get; }
    double Time { get; }
    double Earn { get; }
}