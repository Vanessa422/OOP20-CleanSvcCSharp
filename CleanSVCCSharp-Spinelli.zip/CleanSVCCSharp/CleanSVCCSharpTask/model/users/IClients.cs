using CleanSVCCSharpTask;
public interface IClients
{
    string CF_PIVA { get; }
    string Name { get; }
    string Address { get; }
    string City { get; }
    int Cap { get; }
    string Tel { get; }
    string Email { get; }
    int MqStructure { get; }
}
