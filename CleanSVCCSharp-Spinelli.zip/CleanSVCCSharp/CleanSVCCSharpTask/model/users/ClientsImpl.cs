using CleanSVCCSharpTask;
public class ClientsImpl : IClients
{
    public string CF_PIVA { get; }
    public string Name { get; }
    public string Address { get; }
    public string City { get; }
    public int Cap { get; }
    public string Tel { get; }
    public string Email { get; }
    public int MqStructure { get; }
    public ClientsImpl(string CF_PIVA, string name, string address, string city, int cap, string tel, string email, int mqStructure)
    {
        this.CF_PIVA = CF_PIVA;
        this.Name = name;
        this.Address = address;
        this.City = city;
        this.Cap = cap;
        this.Tel = tel;
        this.Email = email;
        this.MqStructure = mqStructure;
    }
}
