using System.Collections.Generic;
using CleanSVCCSharpTask;

public interface ICompany 
{    
    void AddAppointment(IAppointments a);
    void RemoveAppointment(IAppointments a);
    IList<IAppointments> GetAppointment();
    IAppointments SearchAppointment(string date, string hour);
}