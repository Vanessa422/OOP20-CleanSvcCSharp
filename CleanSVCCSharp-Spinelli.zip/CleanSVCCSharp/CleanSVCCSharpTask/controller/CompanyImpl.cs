using System.Collections.Generic;
public sealed class CompanyImpl : ICompany 
{

    private static readonly CompanyImpl SINGLETON = new CompanyImpl();
    private readonly IList<IAppointments> appointments = new List<IAppointments>();

    public CompanyImpl() { }
    public static CompanyImpl GetInstance() 
    {
        return SINGLETON;
    }
    
    public void AddAppointment(IAppointments a) 
    {
        this.appointments.Add(a);
    }
    
    public void RemoveAppointment(IAppointments a) 
    {
        this.appointments.Remove(a);
    }

    public IList<IAppointments> GetAppointment() 
    {
        return appointments;
    }

    public IAppointments SearchAppointment(string date, string hour) 
    {
        foreach (IAppointments a in this.appointments) 
        {
            if(a.Date.Equals(date) && a.Hour.Equals(hour))
            {
                return a;
            }
        }
        return null;
    }
}