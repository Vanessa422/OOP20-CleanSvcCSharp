﻿using System;

namespace CleanSVCCSharpTask
{
    class Program
    { 
        static void Main(string[] args)
        {
        }
    }
}
