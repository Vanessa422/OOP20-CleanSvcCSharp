using Microsoft.VisualStudio.TestTools.UnitTesting;
using CleanSVCCSharpTask;

namespace CleanSVCCSharpTest
{
    [TestClass]
    public class CompanyAppointmentsTest
    {
        private static CompanyImpl company = CompanyImpl.GetInstance();
        private static readonly string DATE = "2021-02-04";
        private static readonly string HOUR = "13:00";
        private static readonly IClients CLIENT = new ClientsImpl("01772160402", "Emporio da Mario", "Via Antonio Montanari 11/13", "Meldola", 47014, "3467529933", "emporiodamario@libero.it", 150);
        private static readonly double TIME = 5.0;
        private static readonly double EARN = 8.0;
        private AppointmentsImpl appointment = null;

        [TestInitialize]
        public void TestAppointmentsImpl() 
        {
            appointment = new AppointmentsImpl(DATE, HOUR, CLIENT, TIME, EARN);
        }

        [TestMethod]
        public void TestAppointment() 
        {
            Assert.IsTrue(appointment.Date.Equals(DATE));
            Assert.IsTrue(appointment.Hour.Equals(HOUR));
            Assert.IsTrue(appointment.Client.Equals(CLIENT));
            Assert.IsTrue(appointment.Time.Equals(TIME));
            Assert.IsTrue(appointment.Earn.Equals(EARN));
        }

        [TestMethod]
        public void TestCompanyAppointments() 
        {
            Assert.IsTrue(company.GetAppointment().Count == 0);
            company.AddAppointment(appointment);
            Assert.IsFalse(company.GetAppointment().Count == 0);
            var app = company.GetAppointment();
            Assert.IsTrue(app[0].Equals(company.SearchAppointment(DATE, HOUR)));
            company.RemoveAppointment(appointment);
            Assert.IsTrue(company.GetAppointment().Count == 0);
        }
    }
}
