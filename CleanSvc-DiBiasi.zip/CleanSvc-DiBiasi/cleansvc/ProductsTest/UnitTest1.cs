using Microsoft.VisualStudio.TestTools.UnitTesting;
using cleansvc;
namespace ProductsTest
{
    [TestClass]
    public class UnitTest1
    {
        private const string Code = "A01";
        private const string Name = "Cleaner PRO";
        private const string Description = "Pulizia ordinaria";
        private const double PricePerLitre = 6.50;
        private const double Usage500mq = 0.33;
        private Products product;
        private Company company = Company.Instance;

        [TestInitialize]
        public void TestInitialize()
        {
            product = new Products(Code, Name, Description, PricePerLitre, Usage500mq);
        }

        [TestMethod]
        public void TestProduct()
        {
            product = new Products(Code, Name, Description, PricePerLitre, Usage500mq);
            Assert.AreEqual(product.Code, Code);
            Assert.AreEqual(product.Name, Name);
            Assert.AreEqual(product.Description, Description);
            Assert.AreEqual(product.PricePerLitre, PricePerLitre);
            Assert.AreEqual(product.Usage500mq, Usage500mq);
        }

        [TestMethod]
        public void TestCompany()
        {
            product = new Products(Code, Name, Description, PricePerLitre, Usage500mq);
            Assert.IsTrue(company.GetProducts().Count == 0);
            company.AddProduct(product);
            Assert.IsFalse(company.GetProducts().Count == 0);
            Assert.IsTrue(company.GetProducts().Contains(product));
            Assert.AreEqual(company.SearchProduct(Code), product);
            company.RemoveProduct(product);
            Assert.IsFalse(company.GetProducts().Contains(product));
            Assert.IsTrue(company.SearchProduct(Code) == null);
            Assert.IsTrue(company.GetProducts().Count == 0);
        }
    }
}
