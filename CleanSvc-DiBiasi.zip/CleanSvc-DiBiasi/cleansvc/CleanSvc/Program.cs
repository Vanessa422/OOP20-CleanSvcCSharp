﻿using System;
#nullable enable
namespace cleansvc
{
    using static InputValidator;
    class Program
    {
        private static InputValidator validator = new InputValidator();
        private static bool allValidated = false;
        static void Main(string[] args)
        {
            /// This main allow to insert the data of a new product and make check on user's input
            /// If some data are wrong the system reask the data
            Console.WriteLine("\n***Welcome to Clean Service Manager!***\nAdd a new product.");
            do
            {
                Console.Write("Code: ");
                string? userCode = Console.ReadLine();
                Console.Write("Name: ");
                string? userName = Console.ReadLine();
                Console.Write("Description: ");
                string? userDescription = Console.ReadLine();
                Console.Write("Price per 500mq: ");
                string? userPrice = Console.ReadLine();
                Console.Write("Usage per 500mq: ");
                string? userUsage = Console.ReadLine();
                if (validator.IsNameAndNum(userCode) && validator.IsName(userName) && validator.IsNameAndNum(userDescription) && validator.IsDouble(userPrice) && validator.IsDouble(userUsage))
                {
                    Products myP = new Products(userCode, userName, userDescription, Convert.ToDouble(userPrice), Convert.ToDouble(userUsage));
                    Console.WriteLine($"\nProdotto '{myP.Name}' inserito con successo!");
                    allValidated = true;
                }
                else
                {
                    Console.WriteLine("\nHai inserito dei dati errati o mancanti! Riprova.\n");
                }
            } while (!allValidated);
        }
    }
}
