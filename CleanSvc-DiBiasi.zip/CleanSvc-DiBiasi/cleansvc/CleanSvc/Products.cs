namespace cleansvc
{
    public class Products : IProducts
    {
        private string code;
        private string name;
        private string description;
        private double pricePerLitre;
        private double usage500mq;

        public string Code
        {
            get { return this.code; }
        }
        public string Name
        {
            get { return this.name; }
        }
        public string Description
        {
            get { return this.description; }
        }
        public double PricePerLitre
        {
            get { return this.pricePerLitre; }
        }
        public double Usage500mq
        {
            get { return this.usage500mq; }
        }

        public Products(string code, string name, string description, double pricePerLitre, double usage500mq)
        {
            this.code = code;
            this.name = name;
            this.description = description;
            this.pricePerLitre = pricePerLitre;
            this.usage500mq = usage500mq;
        }
    }
}