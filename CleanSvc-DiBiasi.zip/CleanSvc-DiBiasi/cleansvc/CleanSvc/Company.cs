namespace cleansvc
{
    using static Products;
    using System.Collections.Generic;
    #nullable enable
    public sealed class Company : ICompany
    {
        private static Company instance = new Company();
        private List<Products> myProducts = new List<Products>();
        private Company() {}
        public static Company Instance
        {
            get
            {
                return instance;
            }
        }
        public void AddProduct (Products product)
        {
            myProducts.Add(product);
        }
        public void RemoveProduct (Products product)
        {
            myProducts.Remove(product);
        }
        public Products? SearchProduct (string code)
        {
            return this.myProducts.Find(x => x.Code.Contains(code));
        }
        public List<Products> GetProducts ()
        {
            return this.myProducts;
        }
    }
}