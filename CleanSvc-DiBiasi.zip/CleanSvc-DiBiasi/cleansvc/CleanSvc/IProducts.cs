namespace cleansvc
{
    interface IProducts
    {
        string Code { get; }
        string Name { get; }
        string Description { get; }
        double PricePerLitre { get; }
        double Usage500mq { get; }
    }
}