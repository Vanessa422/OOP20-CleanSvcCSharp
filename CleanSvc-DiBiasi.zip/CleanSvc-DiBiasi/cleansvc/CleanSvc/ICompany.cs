namespace cleansvc
{   
    using static Products; 
    using System.Collections.Generic;
    #nullable enable
    interface ICompany
    {
        void AddProduct (Products product);
        void RemoveProduct (Products product);
        Products? SearchProduct (string code);
        List<Products> GetProducts ();
    }
}