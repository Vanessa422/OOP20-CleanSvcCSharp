using System.Text.RegularExpressions;
namespace cleansvc
{
    public class InputValidator
    {
        ///regex
        private Regex name = new Regex(@"^[A-Za-z ]*$");
        private Regex nameAndNum = new Regex(@"^[A-Za-z0-9 ]*$");
        private double number;
        //metodi validator bool
        public bool IsName(string inputText)
        {
            return name.IsMatch(inputText);
        }

        public bool IsNameAndNum(string inputText)
        {
            return nameAndNum.IsMatch(inputText);
        }

        public bool IsDouble(string inputText)
        {
            return double.TryParse(inputText, out number);
        }
    }
}