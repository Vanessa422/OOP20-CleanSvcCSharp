﻿using System;
using CleanSvcCSharp.Controller;
using CleanSvcCSharp.Model;

namespace CleanSvcCSharp
{
   
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
