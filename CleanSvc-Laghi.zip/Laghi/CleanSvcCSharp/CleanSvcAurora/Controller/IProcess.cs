using System;
using CleanSvcCSharp.Model;
using System.Collections.Generic;
#nullable enable

namespace CleanSvcCSharp.Controller
{
    public interface IProcess
    {
        void AddStep(SubSteps s);
        void RemoveStep(SubSteps s);
        List<SubSteps> GetSubStepList();
        string[] GetStepTypeList();
       double GetProportialTime(double value, int mq, int staff);
       double GetProportialCost(double value, int mq);
       double GetIncome(double value);
       SubSteps? SearchSubStep(string code);  

    }
}