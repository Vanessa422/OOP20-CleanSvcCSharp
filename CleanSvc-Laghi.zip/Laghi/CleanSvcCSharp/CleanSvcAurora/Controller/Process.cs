using System;
using System.Collections.Generic;
using CleanSvcCSharp.Model;
#nullable enable

namespace CleanSvcCSharp.Controller
{
    public sealed class Process : IProcess
    {
        private List<SubSteps> stepList = new List<SubSteps>();
        private string[] step = Enum.GetNames(typeof(StepType));
        private static Process instance = new Process();
        
        public Process()
        {
        }

        public List<SubSteps> GetSubStepList()
        {
            return this.stepList;
        }

        public string[] GetStepTypeList()
        {
            return step;
           
        }

        public void AddStep(SubSteps s)
        {
            this.stepList.Add(s);
        }

        public double GetIncome(double value)
        {
           double tot = 0;
           tot = value * 1.5 * 1.22;
           return tot;
        }

        public void RemoveStep(SubSteps s)
        {
             this.stepList.Remove(s);
        }

        public SubSteps? SearchSubStep(string code)
        {
           return this.stepList.Find(x => x.Code.Contains(code));
        }

        public double GetProportialTime(double value, int mq, int staff)
        {
           double tot = 0;
           tot = (value * mq) / 500 * staff;
           return tot;
        }

        public double GetProportialCost(double value, int mq)
        {
           return GetProportialTime(value,mq,1);
        }

        // public List<SubSteps>? GetSubSearchByStepType(string stepType)
        // {
            
        // }

        public static Process Instance
        {
            get
            {
                return instance;
            }
        }
    }

}