using System;

namespace CleanSvcCSharp.Model
{
    public class SubSteps : ISubSteps
    {
        private string type;

        private string code;

        private int time500mq;

        private string name;

        private string description;

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public string Description
        {
            get
            {
                return this.description;
            }
        }
        public int Time
        {
            get
            {
                return this.time500mq;
            }
        }

        public string StepType
        {
            get
            {
                return this.type;
            }
        }

        public string Code
        {
            get
            {
                return this.code;
            }
        }


        public SubSteps(string codeSubStep, int timeSubStep, string nameSubStep, string descriptionSubStep, string typeStep)
        {
            this.code = codeSubStep;
            this.name = nameSubStep;
            this.description = descriptionSubStep;
            this.type =  typeStep;
            this.time500mq = timeSubStep;

        }
    }
}