using System;
using System.Collections.Generic;

namespace CleanSvcCSharp.Model
{
    public enum StepType
    {
        CLEANING,
        CLEANSING,
        DISINFECTION,
        DISINFESTATION,
        CONCLUSION
    }
}