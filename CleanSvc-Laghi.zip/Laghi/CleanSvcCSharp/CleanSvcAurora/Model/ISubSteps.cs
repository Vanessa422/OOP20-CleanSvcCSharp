using System;

namespace CleanSvcCSharp.Model
{
    interface ISubSteps
    {
        string Name {get;}

        string Description {get;}

        int Time {get;}

        string Code {get;}

        string StepType {get;}
    }
    
}