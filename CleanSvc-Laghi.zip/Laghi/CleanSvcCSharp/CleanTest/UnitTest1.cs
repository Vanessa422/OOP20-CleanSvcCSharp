using Microsoft.VisualStudio.TestTools.UnitTesting;
using CleanSvcCSharp.Model;
using CleanSvcCSharp.Controller;

namespace CleanTest
{
    [TestClass]
    public class UnitTest1
    {
        private SubSteps step;
        private Process process;

        private static string Code = "S1";
        private static string Name = "Pulizia Tastiere";
        private static string Description = "Pulizia attraverso Spray";
        private static int Time = 12;
        private static string Type = "CLEANING";
        private static int Mq = 500;
        private static double ValueTime = 120;
        private static double ValueCost = 170;
        private static int Nstaff = 1;



        [TestInitialize]
        public void initialize()
        {
            step = new SubSteps(Code,Time,Name,Description,Type);
        }

        [TestMethod]
        public void TestSubSteps()
        {
            step = new SubSteps(Code,Time,Name,Description,Type);
            Assert.AreEqual(step.Code,Code);
            Assert.AreEqual(step.Name,Name);
            Assert.AreEqual(step.Time,Time);
            Assert.AreEqual(step.Description,Description);
            Assert.AreEqual(step.StepType,Type);
        }

        public void TestProcess()
        {
            step = new SubSteps(Code,Time,Name,Description,Type);
            Assert.IsTrue(process.GetSubStepList()==null);
            process.AddStep(step);
            Assert.IsFalse(process.GetSubStepList()==null);
            Assert.IsTrue(process.GetSubStepList().Contains(step));
            Assert.AreEqual(process.SearchSubStep(Code), step);
            process.RemoveStep(step);
            Assert.IsTrue(process.GetSubStepList()==null);
        }

        public void TestMathOperation()
        {
            double totCost = ValueCost * 1.5 * 1.22;
            Assert.AreEqual(process.GetProportialTime(ValueTime,Mq,Nstaff),ValueTime);
            Assert.AreEqual(process.GetProportialCost(ValueCost,Mq),ValueCost);
            Assert.AreEqual(process.GetIncome(ValueCost),totCost);

        }
    }
}
